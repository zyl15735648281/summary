<template>
    <div>Hello Vue666</div>
</template>
