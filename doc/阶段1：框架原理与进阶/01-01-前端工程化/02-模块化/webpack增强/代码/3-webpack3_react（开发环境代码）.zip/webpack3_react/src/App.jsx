import React from 'react'

import { hot } from 'react-hot-loader'

class App extends React.Component{
    render(){
        return <div>
            Hello React 666
        </div>
    }
}

export default hot(module)(App)