[![Build Status](https://travis-ci.org/Duanzihuang/testing2.svg?branch=master)](https://travis-ci.org/Duanzihuang/testing2)
[![codecov](https://codecov.io/gh/Duanzihuang/testing2/branch/master/graph/badge.svg)](https://codecov.io/gh/Duanzihuang/testing2)
# testing2
测试持续集成
