<template>
    <div>
        <router-link to="/foods">食品</router-link>
        <router-link to="/news">新闻</router-link>

        <router-view></router-view>
    </div>
</template>
