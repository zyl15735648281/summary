//导包
import React from 'react'
import ReactDom from 'react-dom'

//导入根组件
import App from './App.jsx'

//渲染根组件
ReactDom.render(<App/>,document.getElementById("root"))

