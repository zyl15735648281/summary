export default {
  name: '我是a'
}