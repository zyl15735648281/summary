<template>
    <div>Hello Vue 666</div>
</template>
