<template>
    <div>
        <div>hello vue</div>
        <div class="div1">测试1</div>
        <div class="div2">测试2</div>
        <div class="div3">测试3</div>
    </div>
</template>

<style scoped>
    @import "./css/test1.css";
    @import "./css/test2.less";
    @import "./css/test3.scss";
</style>
>

</style>


<script>
export default {
	created() {
		console.info('111111')
	}
}
</script>
