// CommonJS规范  在浏览器中不支持
// let a = require('./a.js')

// ES6的导入导出语法规范
import a from './a.js'
console.log(a)
console.log('黑马程序员真牛逼!')
console.log('黑马程序员真牛逼! 是的牛逼!!!')