import $ from 'jquery'
$(function() {
  $('<div></div>').html('我是other').appendTo('body')
})