export default {
  foo: 'bar'
}
