import {getTotalCount} from '@/common/localStorageHelper'

export default {
    buyCount : getTotalCount()
}