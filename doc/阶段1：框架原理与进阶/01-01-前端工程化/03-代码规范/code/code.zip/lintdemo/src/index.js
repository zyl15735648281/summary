const name = '小明'

const age=20

/* eslint-disable */
console.log(name)
console.log(age)

// console.info(name)
// console.warn(age)