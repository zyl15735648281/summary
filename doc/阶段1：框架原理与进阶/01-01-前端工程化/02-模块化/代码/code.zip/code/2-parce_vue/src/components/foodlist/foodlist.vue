<template>
    <ul>
        <li>烤鸭</li>
        <li>茶叶蛋</li>
        <li>辣条</li>
    </ul>
</template>
