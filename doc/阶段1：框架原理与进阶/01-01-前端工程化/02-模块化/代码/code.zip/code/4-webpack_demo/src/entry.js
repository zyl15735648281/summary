document.write('It works666.<br/>')
document.write(require('./module'))
// require('!style-loader!css-loader!./site.css')

require('./site.css')