import React from 'react'

const HomeComponent = () =>{
    return <div>
        Home
    </div>
}

export default HomeComponent