module.exports = {
    num1 : n => parseInt(n),
    num2 : n => Number(n)
}