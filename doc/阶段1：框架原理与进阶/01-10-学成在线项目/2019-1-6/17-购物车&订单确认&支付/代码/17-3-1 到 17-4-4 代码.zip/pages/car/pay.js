export default class pay extends React.Component {
    render() {
         return (<div>
支付页面
        </div>)
    }
}