const {add,mul} = require('../src/math.js')
// const assert = require('assert')

// assert.equal(add(1,1),3,"结果不符合")

// Charjs测试
const {should,expect,assert} = require('chai')

//should要先执行一下
// should()
// add(2,3).should.be.equal(5)

// expect(add(2,3)).to.equal(5);

// assert.equal(add(2,3), 5);