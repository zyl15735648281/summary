import module1 from './module1'
import {fn1,fn2} from './module2'

console.log(module1)
fn1()
fn2()