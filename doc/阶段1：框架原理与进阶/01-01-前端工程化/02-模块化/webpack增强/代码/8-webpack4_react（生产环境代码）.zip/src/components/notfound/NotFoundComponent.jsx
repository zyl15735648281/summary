import React from 'react'

const NotFoundComponent = () => {
    return <div style={{display:'flex',flex:1,justifyContent:'center',alignItems:'center',fontSize:30,color:'red'}}>
        亲，路径匹配出错
    </div>
}

export {NotFoundComponent}