export default {
    name:'小王',
    age:29
}