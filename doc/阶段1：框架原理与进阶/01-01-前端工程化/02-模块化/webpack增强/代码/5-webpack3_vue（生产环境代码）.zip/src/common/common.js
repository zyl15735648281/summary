export default {
    apihost:'http://47.106.148.205:8899/'
}