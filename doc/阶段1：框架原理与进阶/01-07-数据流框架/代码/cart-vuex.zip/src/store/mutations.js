export default {
  setFoo (state, payload) {
    state.foo = payload
  }
}
