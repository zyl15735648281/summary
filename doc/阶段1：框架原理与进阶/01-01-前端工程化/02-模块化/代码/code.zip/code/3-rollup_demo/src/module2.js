export const fn1 = () => {
    alert("fn1")
}

export const fn2 = () => {
    alert("fn2")
}