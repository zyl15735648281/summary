<template>
    <ul>
        <li>深圳大暴雨</li>
        <li>佘诗曼 延禧片酬</li>
        <li>猪年春晚总导演</li>
    </ul>
</template>