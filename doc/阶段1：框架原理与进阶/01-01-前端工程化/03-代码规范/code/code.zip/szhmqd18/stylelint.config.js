module.exports = {
    "extends": "stylelint-config-standard",
    "rules": {
        "color-no-invalid-hex": true,
        "string-quotes": "single"
    }
};