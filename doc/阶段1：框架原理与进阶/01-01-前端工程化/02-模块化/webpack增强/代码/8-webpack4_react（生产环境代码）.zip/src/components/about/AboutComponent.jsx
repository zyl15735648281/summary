import React,{Component} from 'react'

export default class AboutComponent extends Component{
    render(){
        return <div>
            <br/>
            <br/>
            <br/>
            ...about
        </div>
    }
}