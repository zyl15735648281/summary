export default {
  state: {
    a: 456
  },
  mutations: {},
  actions: {},
  getters: {}
}
