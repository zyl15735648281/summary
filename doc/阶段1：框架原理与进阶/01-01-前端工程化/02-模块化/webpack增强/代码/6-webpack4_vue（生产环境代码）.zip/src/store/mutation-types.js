//新增商品
export const ADD_GOODS = "ADD_GOODS"

//修改商品
export const UPDATE_GOODS = "UPDATE_GOODS"

//根据ID删除商品
export const DELETEGOODSBYID = "DELETEGOODSBYID"